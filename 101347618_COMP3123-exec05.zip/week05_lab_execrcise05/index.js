const express = require('express');
const app = express();
const router = express.Router();

const user = require("C:\\Users\\mfles\\OneDrive\\Documents\\FullStack\\week05_lab_execrcise05\\user.json")

const path = require('path');
// sendFile will go here
app.get('/', function(req, res) {
  res.sendFile(path.join(__dirname, '/home.html'));
});


router.get('/home', (req,res) => {
  res.send('This is home router');
});

router.get('/user', (req,res) => {
  res.json(user)
});


/*
- Modify /login router to accept username and password as query string parameter
- Read data from user.json file
- If username and  passsword is valid then send resonse as below 
    {
        status: true,
        message: "User Is valid"
    }
- If username is invalid then send response as below 
    {
        status: false,
        message: "User Name is invalid"
    }
- If passsword is invalid then send response as below 
    {
        status: false,
        message: "Password is invalid"
    }
*/
router.get('/login', (req,res) => {
  if(req.query.username === user.username && req.query.password === user.password){
    res.status(200).json({

    status: true,

    message: "User Is valid"

    });
  }else if (req.query.username === user.username){

   res.status(200).json({
  
   status: false,
  
   message: "Password is invalid"
  
   });
  }else{

  res.status(200).json({
  
  status: false,
  
  message: "User Name is invalid"
  
   });
 }
});


router.post("/logout", (req,res) => {
  const username = req.query.username;
	res.send(`<b> ${username} successfully logout.`);
});

app.use('/', router);

app.listen(process.env.port || 8081);

console.log('Web Server is listening at port '+ (process.env.port || 8081));